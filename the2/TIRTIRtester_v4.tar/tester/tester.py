#Welcome to TIRTIR tester :D
#Global var. numberOfInp should be equal to numberOfInp SET in gener_inp.py
#            if you are using my ios, do not change that value
#Total number of inputs used in my tester is 136, not 150 since I eliminated erroneous inputs

import os
import difflib

numberOfInp = 150
total = 0
score = 0
NOT_SAME = []

for i in range(numberOfInp+1):

	if os.path.isfile("./io/input"+str(i)) :
	
		total+=1
		
		os.system("./the2 < ./io/input"+str(i)+" > ./your_out/output"+str(i)) 

		myOUT = open("./io/output"+str(i),'r')
		yourOUT = open("./your_out/output"+str(i),'r')

		myLINES = myOUT.readlines()
		yourLINES = yourOUT.readlines()

		diff = difflib.context_diff(myLINES, yourLINES)

		delta = "".join(diff)

		if len(delta) == 0  :
			score+=1 

		else :
			NOT_SAME.append(i)
					
print str(score) + " / of " + str(total) + " are same"

if NOT_SAME :
	print "These are not same :" + " ".join(str(NOT_SAME[j]) for j in range(len(NOT_SAME)))
		

	


